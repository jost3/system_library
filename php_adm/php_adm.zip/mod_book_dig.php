<?php
session_start();
include('../bd/conex_prest.php');
if (!isset($_SESSION['usuario']) || !isset($_SESSION['token1'])) {
    // Si no ha iniciado sesión, redirigir a la página de inicio de sesión
    header('Location: ../index.html');
    exit();
}
if (!isset($_SESSION['token1']) || empty($_SESSION['token1'])) {
    header("Location: index.html?alerta=incorrecto");
    exit();
}
$tiempoInactividad = 1800; // 600 segundos = 10 minutos
if (isset($_SESSION['last_action'])) {
    $tiempoTranscurrido = time() - $_SESSION['last_action'];

    if ($tiempoTranscurrido > $tiempoInactividad) {
        // Ha pasado más de 10 minutos, redirige al index.html
        header("Location: ../index.html?alerta=sesion-expirada");
        exit();
    } elseif ($tiempoTranscurrido > 0) {
        // Si hay interacción después de los 10 minutos, regenera el token y actualiza el timestamp
        $_SESSION['token1'] = bin2hex(random_bytes(32));
        $_SESSION['last_action'] = time();
    }
}
$_SESSION['last_action'] = time();

if (isset($_GET['id'])) {
    $idLibroD = $_GET['id'];

    $consultaLibroD = "SELECT * FROM libro_dig WHERE ID_LibroD = $idLibroD";
    $resultadoConsulta1 = mysqli_query($conex1, $consultaLibroD);

    if ($resultadoConsulta1) {
        // Obtén los datos del préstamo
        $datosLibro1 = mysqli_fetch_assoc($resultadoConsulta1);
        
    
        $nombre= $datosLibro1 ['Nombre'];
        $autor= $datosLibro1 ['Autor'];
        $año_publ= $datosLibro1 ['Año_Publ'];
        $imagen= $datosLibro1 ['Imagen'];
        $url= $datosLibro1 ['Url'];
        $seccion= $datosLibro1 ['ID_SeccionD'];

    } else {
        $_SESSION['mensaje'] = "Error al obtener información del libro";
        header('Location: loan.php?alerta=error');
        exit(); 
    }
} else {
    $_SESSION['mensaje'] = "ID ddel libro no proporcionado";
    header('Location: loan.php?alerta=error');
    exit();
}
if (isset($_POST['logout'])) {
    // Cerrar sesión
    session_destroy();
    header('Location: ../index.html');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>Modificar - Libro Digital</title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="../img/hessen icono.png" type="image/x-icon"/>
	<!-- CSS Files -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
	<link rel="stylesheet" href="../css1/bootstrap.min.css">
	<link rel="stylesheet" href="../css1/azzara.min.css">
</head>
<style>
  .logo img {
        max-width: 70%; /* Reduzca el ancho máximo de la imagen al contenedor al 40% */
        height: auto; /* Permite que la altura se ajuste automáticamente para mantener la proporción */
    }
</style>
<body>
	<div class="wrapper">
		
		<div class="main-header" >
			<!-- Logo Header -->
			<div class="logo-header">
				
				<a href="inic.php" class="logo">
					<img src="../img/ESCUDO (1) (1).png" alt="HESSEN " class="navbar-brand">
				</a>
				<button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse" data-target="collapse" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon">
						<i class="fa fa-bars"></i>
					</span>
				</button>
				<button class="topbar-toggler more"><i class="fa fa-ellipsis-v"></i></button>
				<div class="navbar-minimize">
					<button class="btn btn-minimize btn-rounded">
						<i class="fa fa-bars"></i>
					</button>
				</div>
			</div>
			<!-- End Logo Header -->

			<!-- Navbar Header -->
			<nav class="navbar navbar-header navbar-expand-lg">
				
				<div class="container-fluid">
					<div class="collapse" id="search-nav">
						<form class="navbar-left navbar-form nav-search mr-md-3" method="get">
							<div class="input-group">
								<div class="input-group-prepend">
									<button type="submit" class="btn btn-search pr-1">
										<i class="fa fa-search search-icon"></i>
									</button>
								</div>
								<input type="text" placeholder="" class="form-control" name="search">
							</div>
						</form>
					</div>
					<ul class="navbar-nav topbar-nav ml-md-auto align-items-center">
						<li class="nav-item toggle-nav-search hidden-caret">
							<a class="nav-link" data-toggle="collapse" href="#search-nav" role="button" aria-expanded="false" aria-controls="search-nav">
								<i class="fa fa-search"></i>
							</a>
						</li>
						<li class="nav-item dropdown hidden-caret">
							<a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#" aria-expanded="false">
								<div class="avatar-sm">
									<?php if (isset($_SESSION['fotoUsuario'])) : ?>
										<?php $base64Image = base64_encode($_SESSION['fotoUsuario']); ?>
										<img src="data:image/jpeg;base64,<?php echo $base64Image; ?>" alt="imagen de perfil" class="avatar-img rounded-circle">
									<?php else : ?>
										<img src="../assets/img/default_profile.jpg" alt="imagen de perfil predeterminada" class="avatar-img rounded-circle">
									<?php endif; ?>	
								</div>
							</a>
							
							<ul class="dropdown-menu dropdown-user animated fadeIn">
								<li>
									<div class="user-box">
										<div class="avatar-lg">
											
											<?php if (isset($_SESSION['fotoUsuario'])) : ?>
												<?php $base64Image = base64_encode($_SESSION['fotoUsuario']); ?>
												<img src="data:image/jpeg;base64,<?php echo $base64Image; ?>" alt="imagen de perfil" class="avatar-img rounded">
											<?php else : ?>
												<img src="../assets/img/default_profile.jpg" alt="imagen de perfil predeterminada" class="avatar-img rounded">
											<?php endif; ?>
										</div>
										<div class="u-text">
											<h4><?php echo $_SESSION['usuario']; ?></h4>
											<p class="text-muted"><?php echo $_SESSION['correoUsuario']; ?></p>
										</div>
									</div>
								</li>
								<li>
									<div class="dropdown-divider"></div>
									<a class="dropdown-item" href="perfil_adm.php">Mi perfil</a>
									
									<div class="dropdown-divider"></div>
									<form method="post" action="">
										<button type="submit" name="logout" class="dropdown-item">Cerrar sesión</button>
									</form>
								</li>
							</ul>
						</li>
						
					</ul>
				</div>
			</nav>
			<!-- End Navbar -->
		</div>

		<!-- Sidebar -->
		<div class="sidebar">
			
			<div class="sidebar-background"></div>
			<div class="sidebar-wrapper scrollbar-inner">
				<div class="sidebar-content">
					<div class="user">
						<div class="avatar-sm float-left mr-2">
							<?php if (isset($_SESSION['fotoUsuario'])) : ?>
								<?php $base64Image = base64_encode($_SESSION['fotoUsuario']); ?>
								<img src="data:image/jpeg;base64,<?php echo $base64Image; ?>" alt="imagen de perfil" class="avatar-img rounded-circle">
							<?php else : ?>
								<img src="../assets/img/default_profile.jpg" alt="imagen de perfil predeterminada" class="avatar-img rounded-circle">
							<?php endif; ?>	
						</div>
						<div class="info">
							<a data-toggle="collapse" href="#collapseExample" aria-expanded="true">
								<span>
									<?php echo $_SESSION['usuario']; ?>
									<span class="user-level"><?php echo $_SESSION['rolUsuario']; ?></span>
									<span class="caret"></span>
								</span>
							</a>
							<div class="clearfix"></div>

							<div class="collapse in" id="collapseExample">
								<ul class="nav">
									<li>
										<a href="#perfil_adm.php">
											<span class="link-collapse">Mi perfil</span>
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<ul class="nav">
						<li class="nav-item ">
							<a href="inic.php">
								<i class="fas fa-home"></i>
								<p>Inicio</p>
							</a>
						</li>
						<li class="nav-section">
							<span class="sidebar-mini-icon">
								<i class="fa fa-ellipsis-h"></i>
							</span>
							<h4 class="text-section">Acciones</h4>
						</li>
						<li class="nav-item">
							<a href="book.php">
								<i class="fas fa-layer-group"></i>
								<p>Libro</p>
							</a>
							
						</li>
						<?php if (isset($_SESSION['rolUsuario']) && strtolower($_SESSION['rolUsuario']) === 'root') : ?>
						<li class="nav-item Active">
							<a href="digital_book.php">
								<i class="fas fa-layer-group"></i>
								<p>Libro Digital</p>
							</a>
							
						</li>
						<?php endif; ?>
						<li class="nav-item ">
							<a  href="loan.php">
								<i class="fas fa-pen-square"></i>
								<p>Prestamo</p>
							</a>
						</li>
						<li class="nav-item">
							<a data-toggle="collapse" href="#tables">
								<i class="fas fa-table"></i>
								<p>Usuarios</p>
								<span class="caret"></span>
							</a>
							<div class="collapse" id="tables">
								<ul class="nav nav-collapse">
									<li>
										<a href="estudent_adm.php">
											<span class="sub-item">Estudiantes</span>
										</a>
									</li>
									<?php if (isset($_SESSION['rolUsuario']) && strtolower($_SESSION['rolUsuario']) === 'root') : ?>
									<li>
										<a href="adm_register.php">
											<span class="sub-item">Administrador</span>
										</a>
									</li>
									<?php endif; ?>
								</ul>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</div>
        <div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title">Modificar un libro Digital</h4>
						<ul class="breadcrumbs">
							<li class="nav-home">
								<a href="inic.php">
									<i class="fas fa-home"></i>
								</a>
							</li>
							<li class="separator">
								<i class="flaticon-right-arrow"></i>
							</li>
							<li class="nav-item">
								<a href="digital_book.php">Libro Digital</a>
							</li>
							<li class="separator">
								<i class="flaticon-right-arrow"></i>
							</li>
							<li class="nav-item">
								<a href="mod_book_dig.php">Modificar un libro</a>
							</li>
						</ul>
					</div>
					<form action="proc_modf_lbd.php" method="post" enctype="multipart/form-data">
					<div class="col-md-6 mx-auto">
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">Datos del libro Digital</div>
                            </div>
                            <div class="card-body">

                                <div class="form-group form-floating-label">
									<label for="inputFloatingLabelTitulo" class="">Id del libro Digital</label>
                                    <input id="inputFloatingLabelTitulo" type="text" class="form-control input-border-bottom" name="id" value="<?php echo $idLibroD; ?>" readonly>
                                
                                </div>
                                <div class="form-group form-floating-label">
                                    <input id="inputFloatingLabelTitulo" type="text" class="form-control input-border-bottom" name="nombre" value="<?php echo $nombre; ?>" required>
                                    <label for="inputFloatingLabelTitulo" class="placeholder">Titulo de libro Digital</label>
                                </div>
                                <div class="form-group form-floating-label">
                                    <input id="inputFloatingLabelAutor" type="text" class="form-control input-border-bottom" name="autor" value="<?php echo $autor; ?>" required>
                                    <label for="inputFloatingLabelAutor" class="placeholder">Autor</label>
                                </div>
                                <div class="form-group form-floating-label">
                                    <input id="inputFloatingLabelEdicion" type="date" class="form-control input-border-bottom" name="edicion" value="<?php echo $año_publ; ?>" required>
                                    <label for="inputFloatingLabelEdicion" class="placeholder">Año de publicacion</label>
                                </div>
                                <div class="form-group form-floating-label">
									<input id="inputFloatingLabelAutor" type="file" class="form-control input-border-bottom" name="imagen">
									<label for="inputFloatingLabelAutor" class="placeholder"></label>
								</div>
                                <div class="form-group form-floating-label">
                                    <input id="inputFloatingLabelUrl" type="text" class="form-control input-border-bottom" name="url" value="<?php echo $url; ?>" required>
                                    <label for="inputFloatingLabelUrl" class="placeholder">Url</label>
                                </div>
                                <div class="form-group form-floating-label">
    								<select id="inputFloatingLabelUrl" class="form-control input-border-bottom" name="seccion" required>
        								<option value="1" <?php if ($seccion == 1) echo 'selected'; ?>>Medicina</option>
        								<option value="2" <?php if ($seccion == 2) echo 'selected'; ?>>Farmacología</option>
        								<option value="3" <?php if ($seccion == 3) echo 'selected'; ?>>Enfermería</option>
        								<option value="4" <?php if ($seccion == 4) echo 'selected'; ?>>Anestesia</option>
        								<option value="5" <?php if ($seccion == 5) echo 'selected'; ?>>Anatomía</option>
    								</select>
    								<label for="inputFloatingLabelUrl" class="placeholder">Sección</label>
								</div>	
                                <div class="card-action text-center">
                                    <button class="btn btn-primary">Cambiar</button>
                                </div>
                            </div>
                        </div>
                    </div>
					</form>
					
			    </div>
			</div>
		</div>
        
		<!-- End Custom template -->
	</div>
</div>
<!--   Core JS Files   -->

<!-- jQuery desde CDN -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<!-- Popper.js desde CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.9.2/umd/popper.min.js"></script>

<!-- Bootstrap desde CDN -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<!-- jQuery UI -->
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>

<!-- jQuery UI Touch Punch -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui-touch-punch/0.2.3/jquery.ui.touch-punch.min.js"></script>

<!-- jQuery Scrollbar -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.scrollbar/0.2.11/jquery.scrollbar.min.js"></script>

<!-- Moment JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>

<!-- Chart JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.11.0/chart.min.js"></script>

<!-- jQuery Sparkline -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.sparkline/2.4.2/jquery.sparkline.min.js"></script>

<!-- Chart Circle -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-circle-progress/1.2.2/circle-progress.min.js"></script>

<!-- Datatables -->
<script src="https://cdn.datatables.net/v/bs4/dt-1.11.5/datatables.min.js"></script>

<!-- Bootstrap Notify -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/mouse0270-bootstrap-notify/3.1.7/bootstrap-notify.min.js"></script>

<!-- Bootstrap Toggle -->
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>

<!-- Sweet Alert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<!-- Azzara JS -->
<script src="../js/adm/ready.js"></script>

</body>
</html>